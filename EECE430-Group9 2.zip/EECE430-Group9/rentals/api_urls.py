from django.urls import path
from .api_views import car_list_api, car_detail_api

urlpatterns = [
    path("cars/", car_list_api, name="car_list_api"),
    path("cars/<int:pk>/", car_detail_api, name="car_detail_api"),
]
