from django.http import JsonResponse, Http404
from .models import Car

def car_list_api(request):
    cars = Car.objects.all().values("id", "make", "model", "price_per_day")
    return JsonResponse(list(cars), safe=False)

def car_detail_api(request, pk):
    try:
        car = Car.objects.values("id", "make", "model", "price_per_day").get(id=pk)
        return JsonResponse(car, safe=False)
    except Car.DoesNotExist:
        raise Http404
